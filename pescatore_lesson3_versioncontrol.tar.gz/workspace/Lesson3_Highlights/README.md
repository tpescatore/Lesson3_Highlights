# Project Name:  Lesson 3 Version Control

## Course Title:
LIS 2360:  Web Application Development

## Assignment Date:  
(Februrary 2, 2017)

## Student Name:  
(Thomas Pescatore)

## Project Description:
(This assignment is helping me get used to the basics of using git and bootstrap.)

## Lessons Learned in the Assignment:
1. (Git is a virtual control system. )
2. (Version Control Systems allow users to track file changes. They are very useful for writers, designers, and developers.)
3. (A local repository is the Repository that resides on a local machine of an individual users.)
